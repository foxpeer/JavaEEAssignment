/*COMP303_Assignment4-Student-Web
 *Liping Wu 300958061
 *4-5-2020
 * */
package spring.boot.jpa.web.student;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.repository.CrudRepository;

public interface StudentRepository extends JpaRepository <Student, Integer>{


}
