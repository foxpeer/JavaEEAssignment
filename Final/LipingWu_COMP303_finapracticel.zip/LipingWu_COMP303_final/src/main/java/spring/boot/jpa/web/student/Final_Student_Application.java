/*COMP303_Assignment4-Student-Web
 *Liping Wu 300958061
 *4-5-2020
 * */

package spring.boot.jpa.web.student;

import java.util.Date;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import org.springframework.context.annotation.Bean;
import spring.boot.jpa.web.student.Student;
import spring.boot.jpa.web.student.StudentRepository;



@SpringBootApplication
public class Final_Student_Application implements WebMvcConfigurer   {

	public static void main(String[] args) {
		SpringApplication.run(Final_Student_Application.class, args);
		System.setProperty("spring.config.name", "student-web");
		System.out.println("Spring boot REST API for Student is start here:  http://localhost:8086/");
	}
	
	
	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController("/").setViewName("index");
		registry.addViewController("/aboutus").setViewName("aboutus");
	}
	
	@Bean
	public ApplicationRunner studentsInitializer(StudentRepository studentRepository) {
		return args -> {		
			if(studentRepository.findAll().size() == 0) {
				studentRepository.saveAndFlush(	new Student(300100101,"TINACHEN","Programming"));
				studentRepository.saveAndFlush(	new Student(300100102,"JASONCHEN","Medical"));
				studentRepository.saveAndFlush(	new Student(300100103,"VIVIANCHEN","Business"));
				studentRepository.saveAndFlush(	new Student(300100104,"MAXWEN","Business"));
				studentRepository.saveAndFlush(	new Student(300100105,"JockMa","MBA"));
			}							
		};
	}
	
}
