/*COMP303_Assignment4-Student-Web
 *Liping Wu 300958061
 *4-5-2020
 * */

package spring.boot.jpa.web.student;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import spring.boot.jpa.web.student.Student;
import spring.boot.jpa.web.student.StudentRepository;


@Controller
public class StudentController {

	@Autowired
	private StudentRepository studentRepository;

	@Autowired
	private HttpSession session;

	@InitBinder
	private void dateBinder(WebDataBinder binder) {
		// The date format to parse or output your dates
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		// Create a new CustomDateEditor
		CustomDateEditor editor = new CustomDateEditor(dateFormat, true);
		// Register it as custom editor for the Date type
		binder.registerCustomEditor(Date.class, editor);
	}

	@RequestMapping("/students_list.html") // frontend url
	public String show(Model model) {
		List<Student> students = studentRepository.findAll();
		System.out.println("got current student list: " + students);
		model.addAttribute("studentList", students);
		return "students/studentList";
	}

	// Read
	@GetMapping(value = "/students_details.html", params = "stdNo") // frontend url
	public String getStudent(@RequestParam("stdNo") int stdNo, Model model) throws Exception {
		model.addAttribute("student", studentRepository.findById(stdNo).get());
		return "students/studentDetails";
	}

	@GetMapping(value = "/students_add.html") // frontend url
	public String createStudent(Model model) throws Exception {
		model.addAttribute("student", new Student());
		return "students/studentAdd";
	}

	// Create
	@PostMapping("/students_add.html")
	public String createStudentPost(@Valid Student student, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "students/studentAdd";
		}
		studentRepository.save(student);
		session.setAttribute("tempMsg", "Create the student  " + student.getStdName() + " successfully");
		return "redirect:/students_list.html";
	}

	// Update
	@GetMapping(value = "/students_update.html", params = "stdNo") // frontend url
	public String updateStudent(@RequestParam("stdNo") int stdNo, Model model) throws Exception {
		model.addAttribute("student", studentRepository.findById(stdNo));
		return "students/studentUpdate";
	}

	// Update
	@PostMapping("/students_update.html")
	public String updateStudentPost(@Valid Student student, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "students/studentUpdate";
		}
		studentRepository.save(student);
		session.setAttribute("tempMsg", "Update the student  " + student.getStdName() + " successfully");
		return "redirect:/students_list.html";
	}

	// Delete
	@RequestMapping(value = "/students_delete.html", method = RequestMethod.GET)
	public String deleteStudent(@RequestParam("stdNo") int stdNo, Model model) throws Exception {
		Student student = studentRepository.findById(stdNo).get();
		model.addAttribute("student", student);
		String message = "Are you sure you want to delete this student " + student.getStdName() + " ?";
		model.addAttribute("confirmMsg", message);
		return "students/studentDelete";
	}

	// DELETE post
	@RequestMapping(value = "/students_delete.html", method = RequestMethod.POST)
	public String deleteStudentPost(@RequestParam("stdNo") int stdNo, Model model) {
		Student student = studentRepository.findById(stdNo).get();
		String stdName = student.getStdName();
		studentRepository.deleteById(stdNo);

		session.setAttribute("tempMsg", "Deleted the student  " + stdName + " successfully");
		return "redirect:/students_list.html";
	}

}