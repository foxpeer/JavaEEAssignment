/*COMP303_Assignment4-Student-Web
 *Liping Wu 300958061
 *4-5-2020
 * */
package spring.boot.jpa.web.student;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="student")
public class Student {
	@Id	
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "stdno")	
	private int stdNo;
	
	@Column(name = "stdname")
	@Size(min=2,max=30)
	private String stdName;
	
	@Column(name = "course")
	@NotBlank (message="course shouldn't be none")	
	private String course;
	
	

	public int getStdNo() {
		return stdNo;
	}



	public String getStdName() {
		return stdName;
	}



	public String getCourse() {
		return course;
	}



	public void setStdNo(int stdNo) {
		this.stdNo = stdNo;
	}



	public void setStdName(String stdName) {
		this.stdName = stdName;
	}



	public void setCourse(String course) {
		this.course = course;
	}

	public Student() {
		super();
	}



	public Student(int stdNo, String stdName, String course) {
		super();
		this.stdNo = stdNo;
		this.stdName = stdName;
		this.course = course;
	}



	@Override
	public String toString() {
		return "Student [stdNo=" + stdNo + ", stdName=" + stdName + ", course=" + course + "]";
	}
}
