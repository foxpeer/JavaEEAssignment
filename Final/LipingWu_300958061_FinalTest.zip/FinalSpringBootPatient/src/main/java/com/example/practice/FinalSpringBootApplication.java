// Liping Wu 300958061 COMP303 Final 

package com.example.practice;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


@SpringBootApplication
public class FinalSpringBootApplication implements WebMvcConfigurer{

	public static void main(String[] args) {
		SpringApplication.run(FinalSpringBootApplication.class, args);
		System.setProperty("spring.config.name", "patient");
		System.out.println("Spring boot for patient is start here:  http://localhost:8088/");
	}
	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController("/").setViewName("index");		
	}
	
	
	@Bean
	public ApplicationRunner patientsInitializer(PatientRepository patientRepository) {
		return args -> {		
			if(patientRepository.findAll().size() == 0) {
				
				patientRepository.saveAndFlush(new Patient(1, "Jackson", "Dr. Wu", "Jackson@test.com", "High", 61.5, 180.0 ));
				patientRepository.saveAndFlush(new Patient(2, "Jack", "Dr. Chen", "Jackson@test.com", "High", 71.5, 170.7 ));
				patientRepository.saveAndFlush(new Patient(3, "John", "Dr. Li", "Jackson@test.com", "High", 81.5, 180.6));
			}				
		};
	}
	

}
