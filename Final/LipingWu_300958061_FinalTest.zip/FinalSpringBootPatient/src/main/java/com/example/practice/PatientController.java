// Liping Wu 300958061 COMP303 Final
package com.example.practice;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class PatientController {

	@Autowired
	private PatientRepository patientRepository;

	@Autowired
	private HttpSession session;

	
	@RequestMapping("/list.html") // frontend url
	public String show(Model model) {
		List<Patient> patients = patientRepository.findAll();
		long count= patientRepository.count();
		System.out.println("got current patient list: " + patients);
		model.addAttribute("patientList", patients);
		model.addAttribute("count", count);
		
		//display action msg once and then dispear
		model.addAttribute("actionMsg", session.getAttribute("tempMsg"));
		session.removeAttribute("tempMsg");
		
		return "patients/list";  //file of webpage
	}

	// Read
	@GetMapping(value = "/details.html", params = "id") // frontend url
	public String getPatient(@RequestParam("id") int id, Model model) throws Exception {
		if (!patientRepository.existsById(id)) {
			model.addAttribute("error", "The id is not exist");
			return "errorMsg";
		}
		model.addAttribute("patient", patientRepository.findById(id).get());
		return "patients/details";
	}

	@GetMapping(value = "/add.html") // frontend url
	public String createPatient(Model model) throws Exception {
		model.addAttribute("patient", new Patient());
		return "patients/add";
	}

	// Create
	@PostMapping("/add.html")
	public String createPatientPost(@Valid Patient patient, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "patients/add";
		}
		patientRepository.save(patient);
		session.setAttribute("tempMsg", "Create the patient  " + patient.getPatientName() + " successfully");
		return "redirect:/list.html";
	}
	

	// Update
	@GetMapping(value = "/update.html", params = "id") // frontend url
	public String updatePatient(@RequestParam("id") int id, Model model) throws Exception {
		
		if (!patientRepository.existsById(id)) {
			model.addAttribute("error", "The id is not exist");
			return "errorMsg";
		}
		model.addAttribute("patient", patientRepository.findById(id));
		return "patients/update";
	}

	// Update
	@PostMapping("/update.html")
	public String updatePatientPost(@Valid Patient patient, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "patients/update";
		}
		patientRepository.save(patient);
		session.setAttribute("tempMsg", "Update the patient  " + patient.getPatientName() + " successfully");
		return "redirect:/list.html";
	}
	
	

	// Delete
	@RequestMapping(value = "/delete.html", method = RequestMethod.GET)
	public String deletePatient(@RequestParam("id") int id, Model model) throws Exception {
		
		if (!patientRepository.existsById(id)) {
			model.addAttribute("error", "The id is not exist");
			return "errorMsg";
		}
		Patient patient = patientRepository.findById(id).get();
		model.addAttribute("patient", patient);
		String message = "Are you sure you want to delete this patient " + patient.getPatientName()+ " ?";
		model.addAttribute("confirmMsg", message);
		return "patients/delete";
	}

	// DELETE post
	@RequestMapping(value = "/delete.html", method = RequestMethod.POST)
	public String deletePatientPost(@RequestParam("id") int id, Model model) {
	
		Patient patient = patientRepository.findById(id).get();
		String name = patient.getPatientName();
		
		patientRepository.deleteById(id);
		session.setAttribute("tempMsg", "Deleted the patient  " + name + " successfully");
		return "redirect:/list.html";
	}
	

	
}
