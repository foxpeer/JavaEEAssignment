// Liping Wu 300958061 COMP303 Final
package com.example.practice;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="patient")
public class Patient {	
		

		@Id	
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name = "patientid")	
		private int id;
		
		@Column(name = "patientname")
		@Size(min=2,max=30)
		private String patientName;	
		
		@Column(name = "doctorname")
		@Size(min=2,max=30)
		private String docName;	
		
		@Email
		@NotEmpty
		@Column(name = "email")
		private String email;		
		
		
		@Column(name = "bloodgroup")		
		@NotNull
		@Size(min=2,max=30)
		private String bloodgroup;	
		
		@Column(name = "weight")
		@Digits ( fraction = 1, integer = 3)	
		@NotNull
		private double weight;	
		
		@Column(name = "height")
		@Digits ( fraction = 1, integer = 3)	
		@NotNull
		private double height;

		public int getId() {
			return id;
		}

		public String getPatientName() {
			return patientName;
		}

		public String getDocName() {
			return docName;
		}

		public String getEmail() {
			return email;
		}

		public String getBloodgroup() {
			return bloodgroup;
		}

		public double getWeight() {
			return weight;
		}

		public double getHeight() {
			return height;
		}

		public void setId(int id) {
			this.id = id;
		}

		public void setPatientName(String patientName) {
			this.patientName = patientName;
		}

		public void setDocName(String docName) {
			this.docName = docName;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public void setBloodgroup(String bloodgroup) {
			this.bloodgroup = bloodgroup;
		}

		public void setWeight(double weight) {
			this.weight = weight;
		}

		public void setHeight(double height) {
			this.height = height;
		}

		public Patient(int id, String patientName, String docName,
				String email, String bloodgroup,  double weight, double height) {
			super();
			this.id = id;
			this.patientName = patientName;
			this.docName = docName;
			this.email = email;
			this.bloodgroup = bloodgroup;
			this.weight = weight;
			this.height = height;
		}

		public Patient() {
			super();
			// TODO Auto-generated constructor stub
		}

		@Override
		public String toString() {
			return "Patient [id=" + id + ", patientName=" + patientName + ", docName=" + docName + ", email=" + email
					+ ", bloodgroup=" + bloodgroup + ", weight=" + weight + ", height=" + height + "]";
		}
		
		

		
		
		
}
