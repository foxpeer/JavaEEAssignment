package com.mvc.jpa.practice;

import javax.persistence.Entity;
import javax.persistence.Id;

//defining a JPA entity class
@Entity
public class Department {
	//primary key field 
	@Id
	private int deptNo;
	private String deptName;
	private String location;
	
	public int getDeptNo() {
		return deptNo;
	}
	public String getDeptName() {
		return deptName;
	}
	public String getLocation() {
		return location;
	}
	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	@Override
	public String toString() {
		return "Department [deptNo=" + deptNo + ", deptName=" + deptName + ", location=" + location + "]";
	}
	
}