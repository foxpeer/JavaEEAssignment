package com.mvc.jpa.practice;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DepartmentController {
	private static EntityManagerFactory factory;
	private static EntityManager em;
	
	@RequestMapping("/department")
	public ModelAndView view(HttpServletRequest request, HttpServletResponse response) {
		factory = Persistence.createEntityManagerFactory("mysqldbconfig");
		em = factory.createEntityManager();

		//int deptNo = Integer.parseInt(request.getParameter("deptNo"));
		String deptName = request.getParameter("deptName");
		String location = request.getParameter("location");		

		em.getTransaction().begin();
		Department dept = new Department();
		//dept.setDeptNo(deptNo);
		dept.setDeptName(deptName);
		dept.setLocation(location);	

		em.persist(dept);
		em.getTransaction().commit();

		Query query = em.createQuery("select d from Department d");
		List<Department> departmentList = query.getResultList();

		em.close();
		return new ModelAndView("dept_print", "departmentList", departmentList);
	}

	@RequestMapping("/dept_print")
	public ModelAndView add(HttpServletRequest request, HttpServletResponse response) {
		factory = Persistence.createEntityManagerFactory("mysqldbconfig");
		EntityManager em = factory.createEntityManager();

		int deptNo= Integer.parseInt(request.getParameter("deptNo"));
		String deptName=request.getParameter("deptName");
		String location=request.getParameter("location");
		
		em.getTransaction().begin();
		Department dept = new Department();
		dept = em.find(Department.class, deptNo);
		dept.setDeptName(deptName);
		dept.setDeptNo(deptNo);
		dept.setLocation(location);
		
		em.persist(dept);
		em.getTransaction().commit();

		Query query = em.createQuery("select d from Department d");
		List<Department> departmentList = query.getResultList();

		em.close();
		return new ModelAndView("emp_print", "employeeList", departmentList);

	}
}