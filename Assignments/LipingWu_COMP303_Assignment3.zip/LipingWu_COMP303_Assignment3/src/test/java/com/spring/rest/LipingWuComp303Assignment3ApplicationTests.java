package com.spring.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LipingWuComp303Assignment3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
