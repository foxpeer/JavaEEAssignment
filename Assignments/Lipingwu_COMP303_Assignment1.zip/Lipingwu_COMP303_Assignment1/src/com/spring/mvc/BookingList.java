package com.spring.mvc;

import java.util.HashMap;

public class BookingList {
	private HashMap<Integer, Cruise> data = new HashMap<Integer, Cruise> () {};
	private Integer current_booking_id=0;
	public HashMap<Integer, Cruise> getData() {
		return data;
	}
	public Integer getCurrent_booking_id() {
		return current_booking_id;
	}
	public void setData(HashMap<Integer, Cruise> data) {
		this.data = data;
	}
	public void setCurrent_booking_id(Integer current_booking_id) {
		this.current_booking_id = current_booking_id;
	}
	
	public Integer next_booking_id() {
		return ++current_booking_id;
	}

}
