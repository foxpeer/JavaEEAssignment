package com.spring.mvc;

public class Cruise {
	private String firstName;
	private String lastName;
	private String areaCode;
	private String phoneNumber;	
	private String street1;
	private String street2;
	private String city;
	private String state;
	private String postal;
	private String country;
	private String email;	
	private int noOfRooms;
	private String typeOfRoom;
	private Double price;
	private int noOfGuests;
	private Boolean	insideCabin;
	private Boolean	outsideCabin;
	private Boolean senior;
	private double discount;
	private double taxRate;
	private double total;	
	private Integer id;
	
	public Boolean getInsideCabin() {
		return insideCabin;
	}

	public Boolean getOutsideCabin() {
		return outsideCabin;
	}

	public void setInsideCabin(Boolean insideCabin) {
		this.insideCabin = insideCabin;
	}

	public void setOutsideCabin(Boolean outsideCabin) {
		this.outsideCabin = outsideCabin;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	//getters	
	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getStreet1() {
		return street1;
	}

	public String getStreet2() {
		return street2;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getPostal() {
		return postal;
	}

	public String getCountry() {
		return country;
	}

	public String getEmail() {
		return email;
	}

	public int getNoOfRooms() {
		return noOfRooms;
	}

	public String getTypeOfRoom() {
		return typeOfRoom;
	}

	public Double getPrice() {
		return price;
	}

	public int getNoOfGuests() {
		return noOfGuests;
	}

	public Boolean getSenior() {
		return senior;
	}

	public double getDiscount() {
		return discount;
	}

	public double getTaxRate() {
		return taxRate;
	}
	public double getTotal() {
		return total;
	}

	// setters
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setStreet1(String street1) {
		this.street1 = street1;
	}

	public void setStreet2(String street2) {
		this.street2 = street2;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setPostal(String postal) {
		this.postal = postal;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setNoOfRooms(int noOfRooms) {
		this.noOfRooms = noOfRooms;
	}

	public void setTypeOfRoom(String typeOfRoom) {
		this.typeOfRoom = typeOfRoom;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public void setNoOfGuests(int noOfGuests) {
		this.noOfGuests = noOfGuests;
	}

	public void setSenior(Boolean senior) {
		this.senior = senior;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public void setTaxRate(double tax) {
		this.taxRate = tax;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	
	
	@Override
	public String toString() {
		return "Cruise [firstName=" + firstName + ", lastName=" + lastName + ", areaCode=" + areaCode + ", phoneNumber="
				+ phoneNumber + ", street1=" + street1 + ", street2=" + street2 + ", city=" + city + ", state=" + state
				+ ", postal=" + postal + ", country=" + country + ", email=" + email + ", noOfRooms=" + noOfRooms
				+ ", typeOfRoom=" + typeOfRoom + ", price=" + price + ", noOfGuests=" + noOfGuests + ", insideCabin="
				+ insideCabin + ", outsideCabin=" + outsideCabin + ", senior=" + senior + ", discount=" + discount + ", taxRate=" + taxRate + ", total=" + total
				+ "]";
	}

	public Cruise(String firstName, String lastName, String areaCode, String phoneNumber, String street1,
			String street2, String city, String state, String postal, String country, String email, int noOfRooms,
			String typeOfRoom, Double price, int noOfGuests, Boolean insideCabin, Boolean outsideCabin, Boolean senior, double discount,
			double taxRate) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.areaCode = areaCode;
		this.phoneNumber = phoneNumber;
		this.street1 = street1;
		this.street2 = street2;
		this.city = city;
		this.state = state;
		this.postal = postal;
		this.country = country;
		this.email = email;
		this.noOfRooms = noOfRooms;
		this.typeOfRoom = typeOfRoom;
		this.price = price;
		this.noOfGuests = noOfGuests;
		this.insideCabin = insideCabin;
		this.outsideCabin = outsideCabin;
		this.senior = senior;
		this.discount = discount;
		this.taxRate = taxRate;
		this.total = CalculateTotalPrice();
	}

	//method display Passenger Name
	public String displayName() {
		return  "Passenger Name:"+ getFirstName() + " " + getLastName() ;
	}
	public String displayEmail() {
		return  "Email: "+ getEmail() ;
	}
	public String displayTelephone() {
		return "Phone:" + getAreaCode() + "-" + getPhoneNumber();
	}
	public String displayTypeOfCabin() {
		return "Cruise Type: " + getTypeOfCabin();
	}
	public String displayNoOfGuests() {
		return "No of Guests: "+getNoOfGuests();
	}
	public String displayUnitPrice() {
		return "Price:"+ getPrice();
	}
	public String displayAddress() {
		return "Address: "  + getStreet1() +"  " + getStreet2() + ", "+				
				"\n" + getCity() + ", " + getState()  + 
				"\n" + getPostal() + ", "+getCountry();				
	}	
	
	public String getTypeOfCabin( ) {
		return String.format("%s %s", 
				this.insideCabin?" Inside Cabin":"",
				this.outsideCabin?" Outside Cabin":"");
	}
	
	public double CaculatePrice() {
		return this.price * this.noOfGuests;
	}
	
	public double CaculateDiscount() {
		return CaculatePrice() * this.discount;
	}
	
	public double CalculateTax( ) {
		return (CaculatePrice()-CaculateDiscount()) * this.taxRate;	
	}

	public double CalculateTotalPrice( ) {
		return CaculatePrice()-CaculateDiscount() + CalculateTax();	
	}
	
	
	public String displayBooking() {
		return 
		"\n"+ displayName()+ "\n"+
		"\n"+displayEmail()+ "\n"+
		"\n"+displayAddress()+ "\n"+
		"\n"+displayTelephone()+ "\n"+
		"\n"+displayTypeOfCabin()+ "\n"+
		"\n"+displayNoOfGuests() + "\n"+
		"\n"+displayUnitPrice()+"\n";
	}
	
	
	
	
	

}
