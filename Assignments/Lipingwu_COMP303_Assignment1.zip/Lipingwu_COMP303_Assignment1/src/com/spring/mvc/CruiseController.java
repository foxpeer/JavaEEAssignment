package com.spring.mvc;

import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CruiseController {
	
	@Autowired
	ServletContext context;

	@RequestMapping(value = "/index.html", method = RequestMethod.GET)
	public ModelAndView index(HttpServletRequest request, HttpServletResponse reponse) {
		String welcomeMsg = "Welcome to Centennial College Cruise Booking System";
		return new ModelAndView("index", "welcomeMsg", welcomeMsg);
	}
	
	@RequestMapping(value = "/show-cruise.html", method = RequestMethod.POST)
	public ModelAndView showcruise(HttpServletRequest request, HttpServletResponse reponse) {

		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String email = request.getParameter("email");
		String areaCode = request.getParameter("areaCode");
		String phoneNumber = request.getParameter("phoneNumber");
		String street1 = request.getParameter("street1");
		String street2 = request.getParameter("street2");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		String postal = request.getParameter("postal");
		String country = request.getParameter("country");		
		String typeOfRoom = request.getParameter("typeOfRoom");	
		boolean insideCabin = request.getParameter("insideCabin") != null;
		boolean outsideCabin = request.getParameter("outsideCabin") != null;
		Double price =Double.valueOf(request.getParameter("price")) ;
		int noOfRooms=Integer.parseInt(request.getParameter("noOfRooms")) ;
		int noOfGuests=Integer.parseInt(request.getParameter("noOfGuests")) ;		
		boolean senior =request.getParameter("seniorRadio").equalsIgnoreCase("Yes"); //get value from radio button
		System.out.println(request.getParameter("seniorRadio"));
		Double discount = senior ? 0.2 : 0.0;
		Double taxRate = 0.13;
	  
		Cruise cruise = new Cruise(firstName,  lastName,  areaCode,  phoneNumber,  street1,
				 street2,  city,  state,  postal,  country,  email,  noOfRooms,
				 typeOfRoom,  price,  noOfGuests,  insideCabin, outsideCabin,  senior,  discount,
				 taxRate);

		BookingList store = this.getBookingList();
		cruise.setId(store.next_booking_id());
		store.getData().put(cruise.getId(), cruise);
		
		return this.showCruiseDetail(cruise);
	}
	
	private BookingList getBookingList() {
		
		if (context.getAttribute("bookinglist") == null) {
			context.setAttribute("bookinglist", new BookingList());
		}
		BookingList store = (BookingList)context.getAttribute("bookinglist");
		System.out.println(store);
		System.out.println(store.getCurrent_booking_id());
		System.out.println(store.getData());
		return store;
	}
	
	private ModelAndView showCruiseDetail(Cruise cruise) {
		String welcomeMsg = "Welcome to Centennial College Cruise Booking System";
		String thanksMsg = "Thanks for your booking!";
		
		System.out.println(cruise);		
		
		ModelAndView view = new ModelAndView("show-cruise");
		view.addObject("welcomeMsg", welcomeMsg);
		view.addObject("thanksMsg", thanksMsg);
		
		view.addObject("fullName", cruise.displayName());
		view.addObject("email", cruise.displayEmail());	
		view.addObject("phoneNumber",cruise.displayTelephone());	
		view.addObject("address", cruise.displayAddress());	 //whole address information
		
		// separated address information when needed
	    view.addObject("street1", cruise.getStreet1());	  
	    view.addObject("street2", cruise.getStreet2());
	    view.addObject("city", cruise.getCity());
	    view.addObject("state", cruise.getState());	    
	    view.addObject("postal", cruise.getPostal());
	    view.addObject("country", cruise.getCountry());
	    
	    view.addObject("typeOfRoom", cruise.getTypeOfRoom());
	    view.addObject("typeOfCabin", cruise.getTypeOfCabin());
	    view.addObject("seniorRadio", cruise.getSenior());  
	    view.addObject("noOfRooms", cruise.getNoOfRooms());	    
	    view.addObject("noOfGuests", cruise.getNoOfGuests()); 
	   
	   
	    view.addObject("price",  String.format("%.2f", cruise.getPrice()));	   // unit price 
	    view.addObject("basicprice", String.format("%.2f", cruise.CaculatePrice()));	  // price before tax
	    view.addObject("discount",  String.format("%.2f", cruise.CaculateDiscount()));
	    view.addObject("tax",  String.format("%.2f", cruise.CalculateTax()));
	    view.addObject("total", String.format("%.2f", cruise.CalculateTotalPrice()));	    
		
		return view;	
			
	}
	
	@RequestMapping(value = "/cruise_list.html", method = RequestMethod.GET)
	public ModelAndView cruise_list(HttpServletRequest request, HttpServletResponse reponse) {
		String welcomeMsg = "Welcome to Blue Ocean Cruise Booking System";
		ModelAndView view =  new ModelAndView("cruise_list", "welcomeMsg", welcomeMsg);
		
		BookingList store = this.getBookingList();
		view.addObject("bookinglist", store.getData().values());
		view.getModelMap().addAttribute("bookingMap", store.getData()); // another way to pass var to jsp view page
		return view;
	}
	
	@RequestMapping(value = "/cruise_detail.html", method = RequestMethod.GET)
	public ModelAndView cruise_detail(HttpServletRequest request, HttpServletResponse reponse) {
		String welcomeMsg = "Welcome to Blue Ocean Cruise Booking System";
		// todo: got the cruise from hashmap by booking
		Integer bookingid = Integer.parseInt( request.getParameter("id"));
		
		BookingList store = this.getBookingList();
		Cruise cruise =store.getData().get(bookingid);
		if (cruise == null) {
			return new ModelAndView("error", "errMsg", "booking "+bookingid+" is not found.");
		}
		return this.showCruiseDetail(cruise);
	}
	
	@RequestMapping(value = "/contactus.html", method = RequestMethod.GET)
	public ModelAndView contactus(HttpServletRequest request, HttpServletResponse reponse) {
		String welcomeMsg = "Welcome to Centennial College Cruise Booking System";
		return new ModelAndView("contactus", "welcomeMsg", welcomeMsg);
	}
	
	@RequestMapping(value = "/aboutus.html", method = RequestMethod.GET)
	public ModelAndView aboutus(HttpServletRequest request, HttpServletResponse reponse) {
		String welcomeMsg = "Welcome to Centennial College Cruise Booking System";
		return new ModelAndView("aboutus", "welcomeMsg", welcomeMsg);
	}

}
